﻿// Vi du ve School / University - Classes: Student, Seminar, Professor, Enrollment 

using w0502_01_School;

Console.WriteLine("Vi du ve School / University - Classes");


// Student
Student std01 = new Student();
std01.enrollments = new List<Enrollment>();
std01.Name = "Giang A Tu";
std01.Address = "Sai Gon - Cho Lon";
Console.WriteLine(std01.Name);

// Professor 
Professor prof01 = new Professor();

prof01.Name = "Giang A Tia";
prof01.Address = "Bui Doi Cho Lon";
Console.WriteLine($"Giao su: {prof01.Name} o {prof01.Address} ");

// SV + Sem 

Student std02 = new Student();
std02.enrollments = new List<Enrollment>();
std02.Name = "Tong Phu";

Student std03 = new Student();
std03.enrollments = new List<Enrollment>();
std03.Name = "Tong Nu";

Seminar sem01 = new Seminar();
sem01.enrollments = new List<Enrollment>();
sem01.Name = "Tam Sinh Ly hoc";

Seminar sem02 = new Seminar();
sem02.enrollments = new List<Enrollment>();
sem02.Name = "Bac Thay Ban Hang";

Seminar sem03 = new Seminar();
sem03.enrollments = new List<Enrollment>();
sem03.Name = "Tuyen Tap Huan Rose";

sem01.AddStudent(std01);
sem02.AddStudent(std01);
sem03.AddStudent(std01);

sem03.AddStudent(std02);

std01.GetSeminarsTaken();
std02.GetSeminarsTaken();