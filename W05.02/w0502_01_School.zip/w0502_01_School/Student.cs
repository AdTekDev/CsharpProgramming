﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace w0502_01_School
{
    internal class Student
    {
        // Relationship 
        public List<Enrollment> enrollments { get; set; }


        // Properties
        public string Name { get; set; }
        public string Address { get; set; }
        public string PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
        public string StudentNumber { get; set; }
        public double AverageMark { get; set; }

        public List<Seminar> GetSeminarsTaken()
        {
            // Se CODE o day ....
            // ...
            List<Seminar> xlist = new List<Seminar>();

            Console.WriteLine("\n ***Danh sach cac SEMINAR ma SV {0} dang ky: ", this.Name);

            foreach (var enrollment in enrollments)
            {
                xlist.Add(enrollment.SeminarEnroll);
                Console.WriteLine("\n\t {0} ", enrollment.SeminarEnroll.Name);
            }
            return xlist;
        }
    }
}
