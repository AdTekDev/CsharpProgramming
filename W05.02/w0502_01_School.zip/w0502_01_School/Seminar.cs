﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace w0502_01_School
{
    internal class Seminar
    {   
        // Relationship 
        public List<Enrollment> enrollments { get; set; }
        

        // Properties
        public string Name { get; set; }
        public int SeminarNumber { get; set; }
        public float Fees { get; set; }


        // Methods
        public void AddStudent(Student student)
        {
            Enrollment newEnroll = new Enrollment(); 
            newEnroll.StudentEnroll = student;
            newEnroll.SeminarEnroll = this;

            student.enrollments.Add(newEnroll);
            this.enrollments.Add(newEnroll);
        }

        public void DropStudent(Student student)
        {

        }
    }
}
