﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace w0502_01_School
{
    internal class Enrollment
    {
        // Relationship STORED 
        public Student StudentEnroll { get; set; }
        public Seminar SeminarEnroll { get; set; } 

        // Properties / Attributes
        public List<double> MarksReceived { get; set; }

        public double GetAverageToDate()
        {
            // DONE !
            return MarksReceived.Average();
        }

        // Methods / Actions / Behavious
        public double GetFinalMark()
        {
            // Code HERE
            return -1;
        }
    }
}
