﻿namespace w0501_01_students
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Chuong trinh Quan ly DSSV !");

            List<Student> students = new List<Student>();

            //------ Nhap DSSV
            Console.WriteLine("\n\n****** Nhap vao DSSV: ");
            string line = Console.ReadLine();
            while (line != "end")
            {
                string[] words = line.Split(' ');

                string firstName = words[0];
                string lastName = words[1];
                int age = int.Parse(words[2]);
                string city = words[3];

                Student student = students
                    .FirstOrDefault(x => x.FirstName == firstName && x.LastName == lastName);

                if (student != null)
                {
                    student.Age = age;
                    student.City = city;
                    Console.WriteLine($"  Update: {student.FirstName} - {student.LastName} ... {student.Age} - {student.City}");
                } else {
                    student = new Student()
                    {
                        FirstName = firstName,
                        LastName = lastName,
                        Age = age,
                        City = city
                    };

                    students.Add(student);
                    Console.WriteLine($"  Add NEW: {student.FirstName} - {student.LastName}");
                }                 
                
                Console.Write("\n\nNext: ");
                line = Console.ReadLine();
            }

            //------ Tim nguoi o 1 City nao do
            Console.Write("\n\n Can tim nguoi o City nao? ");
            string filtercity = Console.ReadLine();

            foreach (Student studentX in students)
            {
                if (studentX.City == filtercity)
                {
                    Console.WriteLine($"... {studentX.FirstName} - {studentX.LastName}");
                }
            }

            //------ Tim bang LINQ / SQL Query VAR 
            List<Student> filteredStudents = students
                .Where(s => s.City == filtercity)
                .ToList();
            Console.WriteLine("\n\n Tim bang LINQ: ");
            foreach (Student studentX in filteredStudents)
            {
                Console.WriteLine($"... {studentX.FirstName} - {studentX.LastName}");
            }
        }
    }
}